﻿class atividade5
{ 
    public static void Main()
    {
        Console.Write("Digite o valor de um grau em fahrenheit: ");
        int fahren = int.Parse(Console.ReadLine());

        double cels = 5.0 / 9.0 * (fahren - 32);
        
        Console.WriteLine("Graus celcius: " + cels);
    }
}
