﻿using System.ComponentModel.Design;

class Atividade07
{
    public static void Main()
    {
        Console.Write("Digite um valor: ");
        int v1 = int.Parse(Console.ReadLine());
        Console.Write("Digite um outro valor: ");
        int v2 = int.Parse(Console.ReadLine());
        Console.Write("Digite mais um valor: ");
        int v3 = int.Parse(Console.ReadLine());

        double media = (v1 + v2 + v3) / 3;

        if (v1 > media)
        {
            Console.WriteLine("O valor " + v1 + " é superior a media " + media);
        }
        else if (v2 > media)
        {
            Console.WriteLine(" O valor " + v2 + " é superior a media " + media);
        }
        else (v3 > media)
        {
            Console.WriteLine(" O valor " + v3 + "é superior a media " + media);
        }
    }
}