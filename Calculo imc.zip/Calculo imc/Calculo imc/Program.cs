﻿class calculoimc
{
    static void Main()
    {
        Console.WriteLine("== calculo de IMC ==");

        Console.Write("nome: ");
        string nome = Console.ReadLine();

        Console.Write("sexo (M/F): ");
        string sexo = Console.ReadLine().ToUpper();

        Console.Write("peso (kg): ");
        double peso = Convert.ToDouble(Console.ReadLine());

        Console.Write("altura (m): ");
        double altura = Convert.ToDouble(Console.ReadLine());

        double imc = peso / (altura * altura);

        string condicao = "";
        double imcMin = 0, imcMax = 0;

        if (sexo == "F")
        {
            if (imc < 19.1)
                condicao = "abaixo do peso";
            else if (imc <= 25.8)
                condicao = "no peso ideal";
            else if (imc <= 27.3)
                condicao = "muito acima do peso";
            else if (imc <= 32.3)
                condicao = "acima do peso ideal";
            else
                condicao = "obeso";

            imcMin = 19.1;
            imcMax = 25.8;
        }
        else if (sexo == "M")
        {
            if (imc < 20.7)
                condicao = "abaixo do peso";
            else if (imc <= 26.4)
                condicao = "No peso ideal";
            else if (imc <= 27.8)
                condicao = "muito acima do peso";
            else if (imc <= 31.1)
                condicao = "acima do peso ideal";
            else
                condicao = "obeso";

            imcMin = 20.7;
            imcMax = 26.4;
        }
        else
        {
            Console.WriteLine("sexo inválido");
            return;
        }

        Console.WriteLine($"\n{nome}, seu IMC é {imc:F2} - {condicao}");

        if (condicao != "no peso ideal")
        {
            double pesoIdealMin = imcMin * altura * altura;
            double pesoIdealMax = imcMax * altura * altura;

            if (imc < imcMin)
            {
                double ganhar = pesoIdealMin - peso;
                Console.WriteLine($"Você precisa ganhar aproximadamente {ganhar:F2} kg para atingir o peso ideal");
            }
            else
            {
                double perder = peso - pesoIdealMax;
                Console.WriteLine($"Você precisa perder aproximadamente {perder:F2} kg para atingir o peso ideal");
            }
        }
    }
}