﻿

class atvidade6
{
    public static void Main()
    {
        Console.Write("Digite um numero: ");
            int valor = int.Parse(Console.ReadLine());

        if (valor > 0)
        {
            Console.WriteLine("O valor " + valor + "é um valor positivo");
        }
        else if (valor == 0)
        {
            Console.WriteLine("O valor " + valor + "é um valor neutro.");
        }

        else
        { 
            Console.WriteLine("O valor " + valor + " é um valor negativo");
            }

        }
    }