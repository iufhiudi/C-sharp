﻿class Atividade15
{
    static void Main()
    {
        int[] vetor = new int[40];
        int contadorPares = 0;

        
        Console.WriteLine("Digite 40 valores inteiros:");
        for (int i = 0; i < 40; i++)
        {
            Console.Write($"Valor {i + 1}: ");
            vetor[i] = Convert.ToInt32(Console.ReadLine());

            if (vetor[i] % 2 == 0)
            {
                contadorPares++;
            }
        }

        Console.WriteLine($"\nQuantidade de valores pares no vetor: {contadorPares}");
    }
}