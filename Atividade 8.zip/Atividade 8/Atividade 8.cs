﻿

class Atividade8
{
    static void Main()
    {
      

        Console.Write("Digite o valor de a: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o valor de b: ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o valor de c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        if (a == 0)
        {
            Console.WriteLine("não é uma equação do 2º grau, o valor de 'a' deve ser diferente de zero");
            return;
        }

        
        double delta = b * b - 4 * a * c;

        if (delta < 0)
        {
            Console.WriteLine("A equação não possui raízes reais");
        }
        else if (delta == 0)
        {
            Console.WriteLine("A equação possui uma raiz real");
        }
        else 
        {
            Console.WriteLine("A equação possui duas raízes reais");
        }
    }
}
