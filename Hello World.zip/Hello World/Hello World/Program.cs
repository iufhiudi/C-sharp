﻿using System;
class Atividade01
{
    public static void Main()
    {
        Console.WriteLine("Hello, World!");
        Console.Write("Informe seu nome:");
        string nome = Console.ReadLine();

        Console.Write("Digite sua data de nascimento:");
        int ano = int.Parse(Console.ReadLine());

        int calculo = 2050 - ano;
        Console.WriteLine("Olá " + nome + " Sua idade em 2050 será: " + calculo);
    }
}

