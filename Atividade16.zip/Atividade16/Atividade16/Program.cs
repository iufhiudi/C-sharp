﻿class Atividade16
{
    static void Main()
    {
        const int totalPessoas = 7;
        double altura, maiorAltura = double.MinValue, menorAltura = double.MaxValue;
        double somaAlturaMulheres = 0, somaAlturaTotal = 0;
        int countMulheres = 0, countHomens = 0;

        for (int i = 1; i <= totalPessoas; i++)
        {
            Console.Write($"Digite a altura da {i}ª pessoa (em metros): ");
            altura = Convert.ToDouble(Console.ReadLine());

            Console.Write($"Digite o sexo da {i}ª pessoa (m/f): ");
            string sexo = Console.ReadLine().ToLower();

                maiorAltura = altura;
            if (altura < menorAltura)
                menorAltura = altura;

            
            somaAlturaTotal += altura;

            
            if (sexo == "f")
            {
                somaAlturaMulheres += altura;
                countMulheres++;
            }
            else if (sexo == "m")
            {
                countHomens++;
            }
            else
            {
                Console.WriteLine("Sexo inválido, contando como não informado.");
            }

            Console.WriteLine();
        }

        
        double mediaMulheres = countMulheres > 0 ? somaAlturaMulheres / countMulheres : 0;
        double mediaTotal = somaAlturaTotal / totalPessoas;

        
        Console.WriteLine("===== Resultados =====");
        Console.WriteLine($"Maior altura: {maiorAltura:F2} m");
        Console.WriteLine($"Menor altura: {menorAltura:F2} m");
        if (countMulheres > 0)
            Console.WriteLine($"Média de altura das mulheres: {mediaMulheres:F2} m");
        else
            Console.WriteLine("Nenhuma mulher cadastrada para calcular a média.");
        Console.WriteLine($"Média de altura do grupo: {mediaTotal:F2} m");
        Console.WriteLine($"Total de homens cadastrados: {countHomens}");
    }
}
