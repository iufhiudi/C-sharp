﻿class Atividade14
{
    static void Main()
    {
        int[] vetor = new int[20];

        
        Console.WriteLine("Digite 20 valores inteiros para preencher o vetor:");
        for (int i = 0; i < 20; i++)
        {
            Console.Write($"Valor {i + 1}: ");
            vetor[i] = Convert.ToInt32(Console.ReadLine());
        }

        
        Console.Write("\nDigite o valor que deseja buscar (X): ");
        int x = Convert.ToInt32(Console.ReadLine());

        
        bool encontrado = false;
        for (int i = 0; i < 20; i++)
        {
            if (vetor[i] == x)
            {
                Console.WriteLine($"\nValor {x} encontrado na posição {i} do vetor.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado)
        {
            Console.WriteLine($"\nValor {x} não foi encontrado no vetor.");
        }
    }
}
