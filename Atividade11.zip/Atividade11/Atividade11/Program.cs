﻿class Atividade11
{
    static void Main()
    {
        const int quantidade = 5;
        string nomeMaisVelho = "";
        int idadeMaisVelho = 0;
        int somaIdades = 0;

        for (int i = 1; i <= quantidade; i++)
        {
            Console.Write($"Digite o nome da {i}ª pessoa: ");
            string nome = Console.ReadLine();

            Console.Write($"Digite a idade de {nome}: ");
            int idade = Convert.ToInt32(Console.ReadLine());

            somaIdades += idade;

            if (idade > idadeMaisVelho)
            {
                idadeMaisVelho = idade;
                nomeMaisVelho = nome;
            }

            Console.WriteLine(); 
        }

        double mediaIdade = (double)somaIdades / quantidade;

        Console.WriteLine("=== Resultados ===");
        Console.WriteLine($"Idade média: {mediaIdade:F2} anos");
        Console.WriteLine($"Pessoa mais velha: {nomeMaisVelho} com {idadeMaisVelho} anos");
    }
}
