﻿class Atividade2
{
    public static void Main()
    {
        Console.Write("Digite um numero: ");
        int n1 = int.Parse(Console.ReadLine());
        Console.Write("Digite outro numero: ");
        int n2 = int.Parse(Console.ReadLine());

        int soma = n1 + n2;
        int sub = n1 - n2;
        float divisão = n1 / n2;
        int mult = n1 * n2;

        Console.WriteLine("A soma dos numeros será: " + soma);
            Console.WriteLine("A subração dos numeros será: " + sub);
        Console.WriteLine("A divisão dos numeros será: " + divisão);
        Console.WriteLine("A multiplicação dos numeros será: " + mult);
    }
}