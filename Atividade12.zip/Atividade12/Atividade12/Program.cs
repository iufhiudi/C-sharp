﻿class Atividade12
{
    static void Main()
    {
        double areaTotal = 0;
        string continuar;

        do
        {
           
            Console.Write("Digite o nome do cômodo: ");
            string nomeComodo = Console.ReadLine();

            Console.Write($"Digite a largura do(a) {nomeComodo} (em metros): ");
            double largura = Convert.ToDouble(Console.ReadLine());

            Console.Write($"Digite o comprimento do(a) {nomeComodo} (em metros): ");
            double comprimento = Convert.ToDouble(Console.ReadLine());

           
            double areaComodo = largura * comprimento;
            areaTotal += areaComodo;

            Console.WriteLine($"Área do(a) {nomeComodo}: {areaComodo:F2} m²\n");

           
            Console.Write("Deseja adicionar outro cômodo? (sim/não): ");
            continuar = Console.ReadLine().Trim().ToLower();

            Console.WriteLine(); 

        } while (continuar == "sim");

      
        Console.WriteLine("==================================");
        Console.WriteLine($"Área total da residência: {areaTotal:F2} m²");
    }
}