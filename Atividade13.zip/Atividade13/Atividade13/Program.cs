﻿class Atividade13
{
    static void Main()
    {
        int[] vetor = new int[16];

        
        Console.WriteLine("Digite 16 valores inteiros:");
        for (int i = 0; i < 16; i++)
        {
            Console.Write($"Valor {i + 1}: ");
            vetor[i] = Convert.ToInt32(Console.ReadLine());
        }

      
        for (int i = 0; i < 8; i++)
        {
            int temp = vetor[i];
            vetor[i] = vetor[i + 8];
            vetor[i + 8] = temp;
        }

        
        Console.WriteLine("\nVetor após a troca:");
        for (int i = 0; i < 16; i++)
        {
            Console.Write(vetor[i] + " ");
        }

        Console.WriteLine();
    }
}