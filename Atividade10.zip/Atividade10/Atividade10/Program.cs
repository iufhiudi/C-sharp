﻿class Atividade9
    {
    static void Main()
    {
       
        Console.Write("Digite o nome do aluno: ");
        string nome = Console.ReadLine();

        Console.Write("Digite a primeira nota: ");
        double nota1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite a segunda nota: ");
        double nota2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite a terceira nota: ");
        double nota3 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o número de faltas: ");
        int faltas = Convert.ToInt32(Console.ReadLine());

        
        double media = (nota1 + nota2 + nota3) / 3;

        Console.WriteLine($"\nAluno: {nome}");
        Console.WriteLine($"Média: {media:F2}");
        Console.WriteLine($"Faltas: {faltas}");

        if (faltas > 27)
        {
            Console.WriteLine("Situação: Reprovado por Falta");
        }
        else if (media < 5.0)
        {
            Console.WriteLine("Situação: Reprovado por Média");
        }
        else
        {
            Console.WriteLine("Situação: Aprovado");
        }
    }
}